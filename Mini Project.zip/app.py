from flask import Flask, render_template, request
import lungCancer

app = Flask(__name__)


@app.route("/")
def function():
    return render_template("index.html")


@app.route("/sub", methods=['POST'])
def submit():
    if request.method == "POST":
        fname = request.form["fname"]
        lname = request.form["lname"]
        age = request.form["age"]
        smoke = request.form["smoke"]
        areq = request.form["areq"]
        liquor = request.form["liquor"]

        finalPrediction = lungCancer.predictLungCancer([age,smoke,areq,liquor])
        print("final ans",finalPrediction)

    # return render_template("sub.html", fname=fname, lname=lname, age=age, smoke=smoke, areq = areq, liquor=liquor)


if __name__ == "__main__":
    app.run(debug=True)
